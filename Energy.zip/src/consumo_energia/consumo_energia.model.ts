export interface ConsumoEnergia {
  id: number;
  dataLeitura: string; // ISO: 2025-05-15
  consumo: number;     // em kWh
}
